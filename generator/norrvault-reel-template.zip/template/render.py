import sys, subprocess, os
from playwright.sync_api import sync_playwright
D = os.path.dirname(os.path.abspath(__file__))
mode = sys.argv[1]
FPS = 30
with sync_playwright() as p:
    b = p.chromium.launch(args=['--allow-file-access-from-files','--disable-web-security'])
    pg = b.new_page(viewport={'width': 1080, 'height': 1920})
    pg.goto(f'file://{D}/'+os.environ.get('PAGE','reel4.html'))
    pg.wait_for_selector('body[data-ready="1"]')
    pg.wait_for_timeout(300)
    if mode == 'stills':
        for t in sys.argv[2].split(','):
            pg.evaluate(f'render({t})')
            pg.locator('canvas').screenshot(path=f'{D}/still-{t}.jpg', type='jpeg', quality=80)
    else:
        total = pg.evaluate('TOTAL')
        tmp = f'{D}/raw.mp4'
        ff = subprocess.Popen(['ffmpeg', '-y', '-loglevel', 'error', '-f', 'image2pipe', '-framerate', str(FPS), '-c:v', 'mjpeg', '-i', '-',
                               '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '20', '-pix_fmt', 'yuv420p', tmp], stdin=subprocess.PIPE)
        for f in range(round(total * FPS)):
            data = pg.evaluate(f'(render({f / FPS}), document.getElementById("c").toDataURL("image/jpeg", 0.9))')
            import base64
            ff.stdin.write(base64.b64decode(data.split(',', 1)[1]))
        ff.stdin.close()
        if ff.wait() != 0: sys.exit('ffmpeg failed')
        subprocess.check_call(['ffmpeg', '-y', '-loglevel', 'error', '-i', tmp, '-f', 'lavfi', '-i', 'anullsrc=r=48000:cl=stereo', '-shortest',
                               '-map', '0:v', '-map', '1:a', '-c:v', 'copy', '-c:a', 'aac', '-b:a', '128k', '-movflags', '+faststart', f'{D}/nora-principle-proto.mp4'])
    b.close()
