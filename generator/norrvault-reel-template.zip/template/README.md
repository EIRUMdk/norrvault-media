# Norrvault reel-skabelon (princip-reel, v3, 20. nov. 2026)

- reel4.html: canvas-skabelon. Scener, tekst og accentord ligger i SC-listen (eller window.REEL.scenes).
- nora-stand/point/key/walk/wave.png: Nora-sprites (gennemsigtige), klippet fra nora-poses-sheet.png (Higgsfield gpt_image_2_6, 1 kredit).
- render.py: `python3 render.py stills 1,5,10` (stillbilleder) eller `python3 render.py full` (raw.mp4 + nora-principle-proto.mp4, stille). Kræver Playwright + ffmpeg.
- Stemme: Imogen (Higgsfield seed_audio, voice_id 3811e986-0891-47cf-a1f5-78a1d62a547a). Hele manus i én fil; replikkerne findes med silencedetect og lægges ved scenestart + 0,15 s. Stemme +3 dB, lydtæppe −27 dB, limiter 0,95.
